﻿/*
 * Design by OLIMP
 * author by Duganov Talipzhan
*/

var dictionary = {
    empty: 'Пожалуйста, заполните все поля!'
};

var systems1 = {
    events_amount: 'Количество событий: ',
    system: 'Вид системы: ',
    events: 'Экспресс',
    event: '№ ',
    ratio: 'Коэффициент',
    _return: 'Возврат',
    not_played: 'Проигрыш',
    rate: 'Размер ставки',
    result: 'Вычислить',
    win: 'Выигрыш',
    express_amount: 'Число экспрессов',
    express_rate: 'Сумма ставки на каждый экспресс',
    express_played: 'Сыграло экспрессов',
    express_not_played: 'Не сыграло экспрессов',
    details: 'Детали',
    exrpess_number: '№ экспресса'
};
dictionary.systems = [systems1];