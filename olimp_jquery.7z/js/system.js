﻿/*
 * Design by OLIMP
 * author by Duganov Talipzhan
*/

$( document ).ready(function() {

    // Подгружаем нашу библиотеку
    var dict = dictionary.systems[0];
    $('label[for=eventsAmount]').text(dict.events_amount);
    $('label[for=systems]').text(dict.system);
    $('#events th:eq(0)').text(dict.events);
    $('#events th:eq(1)').text(dict.ratio);
    $('#events th:eq(2)').text(dict._return);
    $('#events th:eq(3)').text(dict.not_played);
    $('input[type=submit]').val(dict.result);
    $('#results tr:eq(0) td:first').text(dict.win);
    $('#results tr:eq(1) td:first').text(dict.express_amount);
    $('#results tr:eq(2) td:first').text(dict.express_rate);
    $('#results tr:eq(3) td:first').text(dict.express_played);
    $('#results tr:eq(4) td:first').text(dict.express_not_played);
    $('#details').text(dict.details);
    $('#detailsTable th:eq(0)').text(dict.exrpess_number);
    $('#detailsTable th:eq(1)').text(dict.ratio);
    $('#detailsTable th:eq(2)').text(dict.rate);
    $('#detailsTable th:eq(3)').text(dict.win);
    $('#alert').text(dictionary.empty);

    var amountControl = $('select[name=eventsAmount]'),
        systemsControl = $('select[name=systems]'),
        validparams = true,
        myBetControl = $('input[name=myBet]');

    function eventsRows(amount) {
        $('#events tbody').html('');
        for(var i=1; i<=amount; i++) {
            var row = '<tr>' +
                '<td name="eventName-' + i + '">'+ dict.event + i + '</td>' +
                '<td><input type="text" class="eventRatio" name="eventConst-' + i + '" value="" /></td>' +
                '<td><input type="checkbox" name="eventBack-' + i + '" /></td>' +
                '<td><input type="checkbox" class="notPlayedEvent" name="eventNot-' + i + '" /></td>' +
                '</tr>';
            $('#events tbody').append(row);
        }
    }

    function f(n) {
        return (n != 1 && n != 0) ? n * f(n - 1) : 1;
    }

    function countWays(system, amount) {
        return f(amount) / f(system) / f(amount - system);
    }

    function combinations(range, system, fake) {
        $.each(range.slice(0,range.length-system+1), function(i, e) {
            if (system == 1) {
                fake[system-1].push(e);
                return;
            } else {
                var rest = range.slice(i+1, range.length);
                var c = countWays(system-1, rest.length);
                for (var j=1; j<=c; j++) {
                    fake[system-1].push(e);
                }
                return combinations(rest, system-1, fake);
            }

        });
    }

    function composeGroups(system, amount) {
        var range = [],
            fake = [];
        for (var i=1; i<=amount; i++) {
            range.push(i);
        }
        for (var i=1; i<=system; i++) {
            fake.push([]);
        }
        combinations(range, system, fake);
        fake.reverse();
        var groups = [];
        for (var i=1; i<=countWays(system, amount); i++) {
            var group = [];
            $.each(fake, function(p, e) {
                group.push(e[i-1]);
            });
            groups.push(group);
        }
        return groups;
    }

    function systems(amount) {
        systemsControl.html('');
        for(var i=2; i<amount; i++) {
            systemsControl.append($('<option/>').attr('value', i).text(i + ' of ' + amount + ' (' + countWays(i, amount) + ')'));
        }
    }

    function showAlert() {
        var valid = true;
        $.each($('.eventRatio, input[name=myBet]'), function(i, field) {
            if ($.trim($(field).val()) == '') {
                valid = false;
                validparams = valid;
            }
        });
        if (!valid) {
            $('#alert').show();
        }else{
            validparams = valid;
        }
    }

    $.each([3,4,5,6,7,8,9,10,11,12], function(i, amount) {
        amountControl.append($('<option/>').attr('value', amount).text(amount));
    });
    amountControl.change(function() {
        var eventsAmount = amountControl.val();
        systems(eventsAmount);
        eventsRows(eventsAmount);
    });
    amountControl.trigger('change');

    $('input[name=myBet], input[name*=eventConst]').keyup(function() {
        $('#alert').hide();
    });

    $('#systems').submit(function(e) {
        e.preventDefault();
        showAlert();
        if(validparams){
       
            var eventsAmount = Number(amountControl.val()),
                system = Number(systemsControl.val()),
                groups = composeGroups(system, eventsAmount),
                notPlayedGroups = 0,
                ratios = [];

            
            $.each(groups, function(i, group) {
                var ratio = 1,
                    notPlayed = false;
                $.each(group, function(j, event) {
                    var val = $.trim($('input[name=eventConst-' + event + ']').val());
                    var cInit = Number(val.replace(',','.')),
                        notPlay = $('input[name=eventNot-' + event + ']').is(':checked'),
                        back = $('input[name=eventBack-' + event + ']').is(':checked');
                    ratio *= notPlay ? 0 : back ? 1 : cInit;
                    if (notPlay || (!cInit && !back)) {
                        notPlayed = notPlayed || true;
                    }
                });
                if (notPlayed) {
                    notPlayedGroups++;
                }
                ratios.push(ratio);
            });
            var myBet = $.trim(myBetControl.val());
            var bet = Number(myBet.replace(',','.')) / countWays(system, eventsAmount),
                wins = [],
                win = 0;
            $.each(ratios, function(i, ratio) {
                wins.push(ratio * bet);
                win += ratio * bet;
            });
               
            // Выводим значения
            $('#win').text(win.toFixed(2));
            $('#groupsAmount').text(groups.length);
            $('#bet').text(bet.toFixed(2));
            $('#playedGroups').text(groups.length - notPlayedGroups);
            $('#notPlayedGroups').text(notPlayedGroups);
            $('#results, #details').show();

            // Детали
            $('#details').click(function() {
                $('#detailsTable tbody').html('');
                $.each(groups, function(i, group) {
                    var pos = i+1;
                    var groupNames = [];
                    $.each(group, function(j, number) {
                        var eventName = $.trim($('input[name=eventName-' + number + ']').val());
                        groupNames.push( eventName ? eventName : 'Event ' + number);
                    });
                    var row = '<tr>' +
                        '<td>' + pos + '</td>' +
                        '<td>' + ratios[i] + '</td>' +
                        '<td>' + bet.toFixed(2) + '</td>' +
                        '<td>' + wins[i].toFixed(2) + '</td>' +
                        '</tr>' +
                        '<tr style="display:none"><td colspan="5">' + groupNames.join(', ') + '</td></tr>';
                    $('#detailsTable tbody').append(row);
                });
                $('#detailsTable').show();

                $('.events').click(function(e) {
                    $(e.currentTarget).parents('tr:first').next().toggle();
                });
            });
        };
    });
});
